# Inventory PWA

1. Push this project to GitHub.
2. On Render, create a new Web Service, link the repo.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Open the live HTTPS link, install app to your phone.
